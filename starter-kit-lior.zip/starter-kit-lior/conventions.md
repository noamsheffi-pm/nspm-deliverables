# Vault Conventions

One page. Read it once, then use it every day.

The point: the vault is not a pile of notes, it is a schema. Later, when Claude
agents read this vault, they can only be trusted because the structure is
predictable. Every rule below exists so a machine can find things without guessing.

---

## Three levels

**Level 1 - product folders.** Top-level folders map 1:1 to the areas you own.
One folder per area, same names you use at work. Plus the cross-cutting folders
(Meetings, Daily Notes, Roadmap, Customers, System, Dashboards, Archive).

**Level 2 - initiative folder.** Every initiative is a folder, not a file, and
every initiative folder has the same shape:

```
{Area}/{Initiative Name}/
├── 00-workplan.md      # the blueprint and the source of truth
├── prd-*.md            # the PRD
├── spec-review-*.md    # architecture or impact review
├── Meetings/           # meetings about this initiative
└── 04-dev/             # engineering breakdown, epics
```

Every artifact links back to `00-workplan.md`. The folder is the context you
hand to Claude later.

**Level 3 - frontmatter.** This is the spine. It is what tools and agents
actually read.

---

## Frontmatter

Every note starts with YAML frontmatter. Obsidian shows it in the Properties
panel (Cmd+.). Dataview queries it.

Workplan (the important one):

```yaml
---
type: workplan
area: Tracing
ticket: CX-12345
phase: discovery | definition | dev | release | done
status: active | paused | done
urgency: low | normal | high
team: ""
sprint: ""
blocker: ""
next-action: "Get sizing from the team lead"
owner: Lior
started: 2026-08-29
last-reviewed: 2026-08-29
---
```

Field meanings that matter:

| Field | What it answers |
|---|---|
| `phase` | What stage the initiative is in. Gate everything on this. |
| `next-action` | What is owed right now, and by whom. |
| `blocker` | Empty means not blocked. Anything else means blocked. |
| `last-reviewed` | Freshness. If it is old, the note is lying to you. |

Other note types:

```yaml
type: meeting | prd | daily | overview | dashboard | decision
```

Rule: if a value contains a colon and a space, quote it. Otherwise the YAML
breaks and Obsidian stops showing Properties.

---

## Tags

Tags go at the **end of the line**. Tools extract by position.

```
- Ask the team lead for sizing #Task
- Waiting on the customer to confirm the trace volume #follow-up
- Decision: we keep spans out of the v1 scope #decision
- Is sampling per-service or per-tenant? #open-question
```

| Tag | Meaning |
|---|---|
| `#Task` | You need to do this |
| `#follow-up` | Waiting on someone else |
| `#decision` | A decision was made, capture it |
| `#open-question` | Unresolved, needs an answer |

---

## Naming

- Initiative folders: plain words, no dates. `Trace Sampling Controls`
- Files inside: `00-workplan.md`, `prd-trace-sampling.md`, `spec-review-2026-08.md`
- Meeting notes: `Meetings/{Person}/{YYYY}/{MM}/DD-MM-YYYY.md`
- Never put a date in a folder name unless the folder is a time bucket.

---

## Links

Use `[[wikilinks]]`, not paths. Set link format to "shortest path when possible".
Every PRD and spec links back to its `00-workplan.md`. That backlink is how you
walk from any artifact to the source of truth.

---

## The one habit

When you close an initiative note, update two fields: `next-action` and
`last-reviewed`. That is the whole discipline. Everything else follows.
