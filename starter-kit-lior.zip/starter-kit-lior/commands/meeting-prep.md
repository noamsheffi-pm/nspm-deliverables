---
name: meeting-prep
description: "Prepare a one-page briefing for an upcoming meeting. Triggers: 'meeting prep', 'prep me for', 'brief me on my meeting with'."
---

Produce a one-page briefing for a meeting. `$ARGUMENTS` is the person, the team,
or the topic.

The test for this skill: after reading it, do you know what you want out of the
meeting, and what is still open from last time.

---

## Gather

Work only from the vault. Do not guess and do not fill gaps with plausible
detail.

1. **Last notes with this person or on this topic.** Look in
   `Meetings/{Person}/` and in the relevant product folder.
2. **Open items.** Every `#Task`, `#follow-up` and `#open-question` in those
   notes that is not ticked.
3. **Related initiatives.** Any `00-workplan.md` in that area where
   `status` is not `done`. Pull `phase`, `blocker` and `next-action`.
4. **Decisions already made.** The `## Decisions` rows in those workplans, so
   you do not reopen a settled question.

If you find nothing, say so plainly: "No previous notes with {person}." Then
produce the agenda section only. A short honest brief beats a padded one.

---

## Output

Write to `Meetings/{Person}/{YYYY}/{MM}/{DD-MM-YYYY}-prep.md`.

```markdown
---
type: meeting-prep
with: "{person}"
area: ""
date: YYYY-MM-DD
---

# Prep — {person}, {date}

## TL;DR
Two lines. Why this meeting matters today and the one thing you need from it.

## Still open from last time
- {item} — from {note}, {date}

## On your side
Initiatives in this area and where they stand.

| Initiative | Phase | Blocker | Next action |
|---|---|---|---|

## What to ask
Three questions, no more. Each one should change what you do next depending on
the answer.

1.
2.
3.

## What they will likely ask you
Two things, with the answer you plan to give.

## Decided already, do not reopen
- {decision} — {date}
```

---

## Rules

- Three questions maximum. A list of ten is not a prep, it is a dump.
- Every open item names its source note and date, so it can be checked.
- If a workplan has no `next-action`, flag it in the brief. That is a real gap
  and the meeting is the place to close it.
- Do not invent context. "Not in the vault" is a valid and useful answer.
- Keep the whole file to one screen.

---

## Finish

Report the path and the three questions in the chat, so the brief is usable
without opening the file.
