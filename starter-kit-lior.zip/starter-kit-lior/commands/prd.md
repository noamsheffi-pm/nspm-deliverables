---
name: prd
description: "Write a PRD for a proposed solution. Triggers: 'prd', 'write a prd', 'create a spec', 'define the requirements'."
---

Write a PRD. `$ARGUMENTS` may be an initiative name, a folder path, a problem
brief, or nothing.

A PRD defines what we are building and how we will know it works. It is not a
design doc and it is not a project plan.

---

## Before you write anything

1. Find the initiative folder. If there is a `00-workplan.md`, read it first.
   The problem statement lives there, not in the PRD.
2. If there is no workplan, say so and offer to run `/workplan` first. A PRD
   with no workplan behind it has nowhere to link back to.
3. Read any existing PRD in the folder. If one exists, ask whether to update it
   rather than write a second one.

---

## The rule that decides quality

**Separate the problem from the solution.** If the problem section already
contains the solution, the PRD is a proposal dressed as a requirement, and no
one can disagree with it usefully. Push back before writing if the input mixes
them.

---

## Structure

Read `System/Templates/prd.md` fresh and fill it.

```yaml
---
type: prd
area: ""
workplan: "[[00-workplan]]"
status: draft | in-review | approved
created: YYYY-MM-DD
---
```

### 1. TL;DR
Three to five lines. What we are building, for whom, and the one measurable
outcome. Someone should be able to stop reading here and still know the answer.

### 2. Problem and evidence
What is broken, for whom, how often. Every claim needs a source: a customer
name, a ticket, a number, a quote. A problem statement with no evidence is an
opinion. If you have no evidence for a claim, write "no evidence yet" and leave
it visible.

### 3. Users and jobs
Who hits this, and what they are trying to get done. Be concrete about the
first user. "All users" means you have not thought about it.

### 4. Requirements

| # | Requirement | Priority | Acceptance |
|---|---|---|---|
| R1 | What the system must do | must / should / could | How we test that it is true |

Every requirement needs an acceptance line that someone could actually check.
If you cannot write the acceptance, the requirement is not a requirement yet.

### 5. Out of scope
What we are deliberately not doing, and why. This section prevents more
arguments than any other.

### 6. Risks and trade-offs
What breaks at 10x. What we are giving up. What we are assuming that could be
wrong. Name the risk plainly, do not soften it.

### 7. Open decisions
- [ ] {decision} — owner, needed by when #open-question

---

## Rules

- Do not invent numbers, customers, or adoption figures. If you do not have the
  number, write what would need to be measured.
- Do not write a solution in the problem section.
- Do not pad. If a section has nothing real in it, write one line saying what is
  missing and who can answer it.
- Never use: seamless, robust, leverage, unlock, empower.
- Requirements are testable statements, not aspirations.

---

## Finish

1. Save to the initiative folder as `prd-{short-name}.md`.
2. Add the PRD link to the workplan's `## Links` section.
3. Report the path and list every open decision and every "no evidence yet"
   line in the chat, so they are visible without opening the file.
