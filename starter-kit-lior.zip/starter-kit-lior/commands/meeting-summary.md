---
name: meeting-summary
description: "Capture a meeting that just happened: decisions, open items, actions. Triggers: 'meeting summary', 'summarize this meeting', 'capture this meeting'."
---

Turn raw meeting input into a structured note. `$ARGUMENTS` is a transcript, a
paste of your own notes, a file path, or nothing, in which case ask for the
input.

The value of this skill is not the summary. It is that decisions and actions
come out as separate, findable things instead of staying buried in prose.

---

## Extract

Read the input once, then pull four things apart. Keep them separate.

| Thing | Test |
|---|---|
| **Decision** | Someone chose. There is now a thing that is settled. |
| **Action** | Someone has to do something. It has an owner. |
| **Open question** | Nobody knows yet, and it is blocking something. |
| **Context** | Everything else worth keeping. |

Most people write all four as one paragraph. Do not.

---

## Rules that decide quality

- **Only what was said.** Do not add a conclusion the room did not reach. Do not
  smooth a disagreement into agreement. If the meeting ended unresolved, the
  note says unresolved.
- **Every action needs an owner and a date.** No owner means it is not an
  action, it is a wish. If the owner was never named, write
  `owner: unassigned` and flag it.
- **A decision with no reason is not worth keeping.** Capture why, in one line.
- **Do not invent.** If the input is unclear on a point, write
  `unclear from the notes` and move on.

---

## Output

Write to `Meetings/{Person or Topic}/{YYYY}/{MM}/{DD-MM-YYYY}.md`. For an
initiative meeting, use the initiative's own `Meetings/` folder instead.

```markdown
---
type: meeting
with: ""
area: ""
date: YYYY-MM-DD
---

# {Meeting} — {date}

## TL;DR
Three lines. What was decided and what happens next.

## Decisions
| Decision | Why | Who |
|---|---|---|

## Actions
- [ ] {what} — {owner}, by {date} #Task
- [ ] {what we are waiting on} — {who}, by {date} #follow-up

## Open questions
- {question} — needs {who} #open-question

## Notes
The rest, in the order it came up.
```

---

## Then update the workplan

If the meeting touched an initiative that has a `00-workplan.md`:

1. Add any decision as a row in its `## Decisions` table.
2. Update `next-action` if the meeting changed it.
3. Update `blocker` if something got blocked or unblocked, and move `status`
   with it.
4. Update `last-reviewed` to today.
5. Add the meeting note to `## Links`.

Show these edits before making them. Do not update a workplan silently.

---

## Finish

Report in the chat:
- the path
- every action with no owner
- every open question

Those two lists are the reason to run this. Do not bury them in the file.
