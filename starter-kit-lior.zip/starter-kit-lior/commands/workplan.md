---
name: workplan
description: "Create or update an initiative workplan (00-workplan.md). Triggers: 'workplan', 'create workplan', 'start initiative', 'track this initiative'."
---

Create or update an initiative `00-workplan.md`. This file is the source of
truth for one initiative. Its frontmatter feeds `Dashboards/portfolio.md` and
every other skill.

`$ARGUMENTS` may be an initiative name, a folder path, a path to a PRD or note
to build from, the word `update`, or nothing.

---

## Before you write anything

1. If `$ARGUMENTS` is a file with frontmatter, inherit `area` and the title from
   it. Do not ask again for what you already have.
2. If a `00-workplan.md` already exists in the target folder, switch to **Update
   mode**. Never overwrite one.
3. If there is no clear initiative, ask: "Which initiative? Name or folder."

---

## Create mode

### Step 1 — Basics

Ask only for what you do not already know:

1. **Initiative name.** Short and specific, two to four words. Drop leading
   verbs ("Create", "Add", "Build") and articles. "Add sampling controls for
   traces" becomes "Trace Sampling Controls".
2. **Area.** One of the top-level product folders in the vault.
3. **One line on the problem.** Not the solution.

### Step 2 — Folder

Use the existing initiative folder if there is one. Otherwise propose
`{Area}/{Initiative Name}/` and confirm before creating it. Never write a
workplan to the vault root.

### Step 3 — Write the file

Read `System/Templates/00-workplan.md` fresh, it may have changed. Write
`00-workplan.md` with this frontmatter:

```yaml
---
type: workplan
area: ""
phase: discovery | definition | dev | release | done
status: active | blocked | paused | done
urgency: low | normal | high
team: ""
sprint: ""
blocker: ""
next-action: ""
owner: Lior
started: YYYY-MM-DD
last-reviewed: YYYY-MM-DD
---
```

Rules:
- `phase` is the lifecycle stage. `status` is the activity lane. They are not
  the same field and they move independently.
- `blocker` empty means not blocked. If you set a blocker, set
  `status: blocked` in the same edit.
- `next-action` is one concrete sentence with an owner in it. Not "follow up".
- If a value contains a colon and a space, quote it.
- Never invent a `phase` or a `next-action`. Ask if you cannot tell.

### Step 4 — Body

```markdown
# {Initiative Name}

## Problem
What is broken today, for whom, and how we know.

## Why now
The trigger. A customer, a cost, a risk, a dependency.

## Scope
In scope and out of scope. Be explicit about what we are not doing.

## Open questions
- [ ] {question} #open-question

## Decisions
| Date | Decision | Who |
|---|---|---|

## Links
- PRD:
- Design:
- Meetings:

## Session log
- YYYY-MM-DD — created
```

---

## Update mode

Do not rewrite the file. Change only what moved.

1. Read the current frontmatter and body.
2. Ask what changed, or take it from `$ARGUMENTS`.
3. Update the fields that actually moved. Always update `last-reviewed` to
   today.
4. Append one line to `## Session log`: `YYYY-MM-DD — {what changed}`.
5. If a decision was made, add a row to `## Decisions`. Do not bury a decision
   in the session log.

---

## Finish

Report in three lines:
- the path you wrote
- `phase` and `status` now
- `next-action` now

If `next-action` is empty, say so and ask for one. An initiative with no next
action is the thing this file exists to catch.
