#!/bin/bash
# Obsidian starter pack - Lior Yogev
# Usage: bash install.sh /path/to/your/vault
# Safe to re-run. It never overwrites a file that already exists.

set -e

VAULT="${1:?Usage: bash install.sh /path/to/your/vault}"
KIT="$(cd "$(dirname "$0")" && pwd)"

# --- EDIT ME -----------------------------------------------------------------
# Top-level product folders. One folder per area you own.
# Change this list to match your portfolio before the first run.
PORTFOLIO=(
  "Tracing"
  "Explore"
)
# -----------------------------------------------------------------------------

CROSS_CUTTING=(
  "Daily Notes"
  "Meetings"
  "Weekly"
  "Customers"
  "Roadmap"
  "Feature Requests"
  "Bugs"
  "Dashboards"
  "System/Templates"
  "System/Attachments"
  "System/References"
  "System/Agents/Claude/commands"
  "System/Agents/Claude/skills"
  "Archive"
)

mkdir -p "$VAULT"

echo "==> Creating folders in $VAULT"
for d in "${PORTFOLIO[@]}" "${CROSS_CUTTING[@]}"; do
  mkdir -p "$VAULT/$d"
done

# Folder landing note per product area, so the folder is not empty and
# Dataview has something to anchor on.
for d in "${PORTFOLIO[@]}"; do
  f="$VAULT/$d/00-overview.md"
  [ -f "$f" ] && continue
  cat > "$f" <<EOF
---
type: overview
area: $d
updated: $(date +%F)
---

# $d

What this area covers, who owns what, where the live work is.

## Active initiatives
\`\`\`dataview
TABLE phase, status, next-action, owner
FROM "$d"
WHERE type = "workplan" AND status != "done"
SORT phase ASC
\`\`\`
EOF
done

echo "==> Copying templates"
for t in "$KIT"/templates/*.md; do
  base="$(basename "$t")"
  [ -f "$VAULT/System/Templates/$base" ] || cp "$t" "$VAULT/System/Templates/$base"
done

echo "==> Copying conventions reference"
[ -f "$VAULT/System/References/conventions.md" ] || cp "$KIT/conventions.md" "$VAULT/System/References/conventions.md"

echo "==> Creating the portfolio dashboard"
DASH="$VAULT/Dashboards/portfolio.md"
if [ ! -f "$DASH" ]; then
  cat > "$DASH" <<'EOF'
---
type: dashboard
---

# Portfolio

## Needs a next action
```dataview
TABLE area, phase, next-action, blocker
WHERE type = "workplan" AND status != "done"
SORT phase ASC
```

## Stale (not reviewed in 14 days)
```dataview
TABLE area, phase, last-reviewed
WHERE type = "workplan" AND status != "done"
  AND (!last-reviewed OR date(last-reviewed) < date(today) - dur(14 days))
SORT last-reviewed ASC
```

## Blocked
```dataview
TABLE area, blocker, owner
WHERE type = "workplan" AND blocker AND blocker != ""
```

## Open tasks across the vault
```tasks
not done
sort by due
limit 30
```
EOF
fi

echo "==> Installing Obsidian settings preset"
mkdir -p "$VAULT/.obsidian"
for f in app.json daily-notes.json; do
  [ -f "$VAULT/.obsidian/$f" ] || cp "$KIT/obsidian-config/$f" "$VAULT/.obsidian/$f"
done

echo "==> Installing the Claude layer (part 2)"
if [ -f "$KIT/CLAUDE.md" ]; then
  if [ -f "$VAULT/CLAUDE.md" ]; then
    echo "    CLAUDE.md already exists, left untouched"
  else
    cp "$KIT/CLAUDE.md" "$VAULT/CLAUDE.md"
    echo "    CLAUDE.md copied. Fill the {{PLACEHOLDERS}} before your first session."
  fi
fi

if [ -d "$KIT/commands" ]; then
  for c in "$KIT"/commands/*.md; do
    base="$(basename "$c")"
    [ -f "$VAULT/System/Agents/Claude/commands/$base" ] || cp "$c" "$VAULT/System/Agents/Claude/commands/$base"
  done
  echo "    commands copied to System/Agents/Claude/commands"
fi

# Point Claude Code at the vault copy, so you can read and edit commands in Obsidian.
if [ -e "$HOME/.claude/commands" ] && [ ! -L "$HOME/.claude/commands" ]; then
  echo "    NOTE: ~/.claude/commands already exists and is a real folder."
  echo "          Left alone. To link it to the vault instead, back it up and run:"
  echo "          ln -s \"$VAULT/System/Agents/Claude/commands\" ~/.claude/commands"
elif [ -L "$HOME/.claude/commands" ]; then
  echo "    ~/.claude/commands is already a symlink, left alone"
else
  mkdir -p "$HOME/.claude"
  ln -s "$VAULT/System/Agents/Claude/commands" "$HOME/.claude/commands"
  echo "    linked ~/.claude/commands -> vault"
fi

echo ""
echo "Done."
echo ""
echo "Next:"
echo "  1. Open Obsidian, 'Open folder as vault', pick: $VAULT"
echo "  2. Install the plugins listed in obsidian-setup.md section 2"
echo "  3. Read System/References/conventions.md once"
echo "  4. Fill the {{PLACEHOLDERS}} in CLAUDE.md:  grep -n '{{' $VAULT/CLAUDE.md"
