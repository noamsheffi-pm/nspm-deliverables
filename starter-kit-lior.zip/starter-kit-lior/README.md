# Obsidian Starter Pack

From Noam. macOS. About 30 minutes to install.

Two parts, one install. Part 1 is the vault: folders, templates, conventions.
Part 2 is the Claude layer: your identity file and four slash commands. The
script sets up both. Do part 1 for a week before you lean on part 2.

---

## What is in the box

```
starter-kit-lior/
├── README.md            # this file
├── install.sh           # run this, it builds everything
├── obsidian-setup.md    # plugins, settings, first week
├── conventions.md       # frontmatter, tags, naming - the contract
├── CLAUDE.md            # your identity file, fill the {{PLACEHOLDERS}}
├── commands/            # four slash commands
├── templates/           # workplan, meeting, daily, prd
└── obsidian-config/     # settings preset the script copies in
```

---

## The four commands

Four, on purpose. More would be worse. Each one writes into the structure part 1
built, and none of them need Jira, Slack or Notion.

| Command | Use it when | Writes to |
|---|---|---|
| `/workplan` | You start or update an initiative | `{Area}/{Initiative}/00-workplan.md` |
| `/prd` | You need to define what gets built | The initiative folder |
| `/meeting-prep` | Before a meeting | `Meetings/{Person}/...-prep.md` |
| `/meeting-summary` | Right after a meeting | `Meetings/{Person}/...md` |

Start with `/workplan`. It is the one that produces the frontmatter everything
else reads. `/meeting-prep` gets useful in week 2, once there are notes for it
to read.

---

## Install

```bash
# 1. Edit the PORTFOLIO list at the top of install.sh to match your areas
open -e install.sh

# 2. Run it
bash install.sh ~/Vault

# 3. Install Obsidian from https://obsidian.md
#    Then: "Open folder as vault" -> pick ~/Vault

# 4. Fill your identity file before the first Claude session
grep -n '{{' ~/Vault/CLAUDE.md
```

The script also links `~/.claude/commands` to the vault folder, so you can read
and edit the commands inside Obsidian. If you already have a real
`~/.claude/commands` folder, it leaves it alone and tells you what to run.

Then follow `obsidian-setup.md` from section 4 (plugins).

The script is safe to re-run. It never overwrites an existing file.

---

## The idea in one paragraph

The vault is a schema, not a pile of notes. Three levels: top-level folders map
to the areas you own, every initiative is a folder with the same shape, and every
initiative has a `00-workplan.md` whose frontmatter is the source of truth. You
get live portfolio views for free today. Later, the same frontmatter is the
interface between you and a set of Claude agents. They can be trusted only
because the structure is predictable.

---

## The one habit that makes it work

When you finish working on an initiative, update two fields in its workplan:
`next-action` and `last-reviewed`.

That is it. The dashboard, the freshness view, and everything in part 2 run off
those two fields.

---

## Not in this pack yet

Agents: jobs that run on a schedule and leave you a short read in the morning.
They work by reading frontmatter across many initiatives, so they need real
content first. Roughly ten live workplans that you actually keep updated. That is
a few weeks of habit, not a date.

---

## Questions

Ping Noam.
