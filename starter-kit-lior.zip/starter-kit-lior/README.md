# Obsidian Starter Pack

From Noam. macOS. About 30 minutes to install.

This is part 1: the vault. It is the foundation. The Claude Code layer (commands,
agents, search) comes in part 2 and it only works if this part is done properly.

---

## What is in the box

```
starter-kit-lior/
├── README.md            # this file
├── install.sh           # run this, it builds the vault
├── obsidian-setup.md    # plugins, settings, first week
├── conventions.md       # frontmatter, tags, naming - the contract
├── templates/           # workplan, meeting, daily, prd
└── obsidian-config/     # settings preset the script copies in
```

---

## Install

```bash
# 1. Edit the PORTFOLIO list at the top of install.sh to match your areas
open -e install.sh

# 2. Run it
bash install.sh ~/Vault

# 3. Install Obsidian from https://obsidian.md
#    Then: "Open folder as vault" -> pick ~/Vault
```

Then follow `obsidian-setup.md` from section 4 (plugins).

The script is safe to re-run. It never overwrites an existing file.

---

## The idea in one paragraph

The vault is a schema, not a pile of notes. Three levels: top-level folders map
to the areas you own, every initiative is a folder with the same shape, and every
initiative has a `00-workplan.md` whose frontmatter is the source of truth. You
get live portfolio views for free today. Later, the same frontmatter is the
interface between you and a set of Claude agents. They can be trusted only
because the structure is predictable.

---

## The one habit that makes it work

When you finish working on an initiative, update two fields in its workplan:
`next-action` and `last-reviewed`.

That is it. The dashboard, the freshness view, and everything in part 2 run off
those two fields.

---

## Questions

Ping Noam.
