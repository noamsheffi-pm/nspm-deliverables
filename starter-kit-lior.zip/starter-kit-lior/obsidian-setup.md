# Obsidian Setup

Obsidian is the surface you and, later, Claude both read and write. If it is not
structured, everything you build on top produces orphan files. This is the
biggest quality lever in the whole setup, so do this part properly.

Time: about 30 minutes.

---

## 1. Install Obsidian

https://obsidian.md - free, macOS native.

Do not open a vault yet. Run the install script first (section 3), then point
Obsidian at the folder it created.

---

## 2. Pick where the vault lives

Any local folder. Two options:

- Fresh start: `~/Vault`
- Existing notes: point at the folder you already have

Avoid iCloud Drive if you can. It causes sync conflicts on large vaults. A git
repo or a plain local folder is better.

---

## 3. Run the install script

```bash
bash install.sh ~/Vault
```

Before you run it, open `install.sh` and edit the `PORTFOLIO` list near the top.
One entry per product area you own. It ships with `Tracing` and `Explore`.

The script is safe to re-run. It never overwrites a file that already exists.

What it creates:

```
~/Vault/
├── Tracing/                 # one folder per area you own
│   └── 00-overview.md
├── Explore/
│   └── 00-overview.md
├── Daily Notes/
├── Meetings/
├── Weekly/
├── Customers/
├── Roadmap/
├── Feature Requests/
├── Bugs/
├── Dashboards/
│   └── portfolio.md         # live views over your frontmatter
├── System/
│   ├── Templates/           # workplan, meeting, daily, prd
│   ├── References/
│   │   └── conventions.md
│   ├── Attachments/
│   └── Agents/Claude/       # empty for now, used in part 2
└── Archive/
```

Then open Obsidian, choose "Open folder as vault", and pick that folder.

---

## 4. Community plugins

Settings → Community plugins → turn them on → Browse → install and enable:

**Must have**

| Plugin | What it does for you |
|---|---|
| `Dataview` | Live tables built from frontmatter. This is what makes the dashboard work. |
| `Templater` | The templates in `System/Templates` become one-keystroke inserts. |
| `Tasks` | Query `#Task` and checkboxes across the whole vault. |
| `Omnisearch` | Fast full-text search. Better than the built-in one. |

**Recommended, add in week 2**

| Plugin | What it does for you |
|---|---|
| `Folder Notes` | Makes `00-overview.md` open when you click the folder. |
| `Tag Wrangler` | Rename a tag everywhere at once. |
| `Recent Files` | Quick access to what you had open. |
| `Excalidraw` | Hand-drawn diagrams inside a note. |
| `Mermaid Tools` | Flow diagrams in markdown. |
| `Quick Explorer` | Navigate the tree from the title bar. |

**Skip for now.** Cortex, BRAT, Custom Sort, File Order, Shell Commands,
Terminal, Orthography, HTML plugin. These are deep customisation. Add one only
when you feel the pain it solves.

---

## 5. Settings to flip once

**Files and links**
- New link format: *Shortest path when possible*
- Use `[[Wikilinks]]`: **on**
- Default location for new notes: *Same folder as current file*
- Attachment folder path: `System/Attachments`

**Editor**
- Default view for new tabs: *Live Preview*

**Daily notes** (core plugin, turn it on)
- New file location: `Daily Notes`
- Date format: `YYYY/MM/DD-MM-YYYY`
- Template file: `System/Templates/daily`

The install script already wrote these last two into `.obsidian/`, so they
should be set. Check them anyway.

**Templater**
- Template folder location: `System/Templates`
- Turn on "Trigger Templater on new file creation" only after you are used to it.

---

## 6. Check it works

1. Open `Dashboards/portfolio.md`. The Dataview blocks should render as tables.
   They will be empty until you have a workplan. That is correct.
2. Create a test initiative:
   ```bash
   mkdir -p ~/Vault/Tracing/"Test Initiative"
   cp ~/Vault/System/Templates/00-workplan.md ~/Vault/Tracing/"Test Initiative"/00-workplan.md
   ```
3. Open it, fill `area`, `phase` and `next-action`.
4. Go back to `Dashboards/portfolio.md`. The row should appear.

If the row does not appear, the frontmatter is malformed. Most common cause: an
unquoted value containing a colon and a space.

---

## 7. Read the conventions

`System/References/conventions.md`. Read it once, today. It is one page and it
is the contract that makes everything later possible.

---

## 8. First week

| When | Do |
|---|---|
| Day 1 | Run the script, install the 4 must-have plugins, read conventions. |
| Day 2 | Take every meeting note in the vault using the meeting template. |
| Day 3 | Create a real `00-workplan.md` for one live initiative. Fill it honestly. |
| Day 4 | Create workplans for the rest. Check the dashboard shows them all. |
| Day 5 | Update `next-action` and `last-reviewed` on all of them. |

Do not add plugins in week 1. Get the structure into your hands first.

---

## What comes next (part 2, not in this pack)

Once the vault has real content and the frontmatter is a habit, the Claude Code
layer goes on top: `CLAUDE.md`, slash commands, semantic search over the vault,
and scheduled agents. That layer only works because of the structure you build
now. It reads the same frontmatter.

Ping Noam when you are ready for it.
