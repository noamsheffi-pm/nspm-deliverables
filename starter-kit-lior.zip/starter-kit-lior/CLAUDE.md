# Lior Yogev — Product Workspace

> Template from Noam. Fill every `{{PLACEHOLDER}}` before the first session.
> Find what is left: `grep -n '{{' CLAUDE.md`

This file is the first thing Claude reads in every session. It is the difference
between generic PM output and output that sounds like your work. Spend 15
minutes on it once.

---

## Role

Product Manager at Coralogix, Analytics and Data Products, reporting to
Aviv Haimovitch.

I own the trace investigation experience: how a user goes from a symptom to the
span that explains it. That covers {{ONE_LINE_ON_WHAT_YOU_ACTUALLY_OWN}}.

Assume I understand distributed tracing, OpenTelemetry, sampling, and query
engines. Do not explain observability basics.

---

## Portfolio

| Area | What it is | Backend | Frontend |
|---|---|---|---|
| Tracing | {{ONE_LINE}} | Radiant | Nimbus |
| Drill-Down | {{ONE_LINE}} | {{TEAM}} | Nimbus |
| Explore | {{ONE_LINE}} | {{TEAM}} | Nimbus |

Not mine, do not pull into my work: monetization and quota (Noam), DataPrime
and datasets (Lior Redlus), RUM (Aviv Alush).

---

## Vault contract

The vault is a schema. Read `System/References/conventions.md` once, then hold
to it. Three rules that matter for every file you write:

1. Every initiative is a folder. Its `00-workplan.md` is the source of truth.
2. Every file you create gets YAML frontmatter. If a value has a colon and a
   space in it, quote it.
3. Tags go at the end of the line: `#Task`, `#follow-up`, `#decision`,
   `#open-question`.

Never write a file to the vault root. Put it in the folder its content belongs
to. If you are not sure which folder, ask before writing.

---

## Hard rules I hold

These gate every review. Add your own as you hit them.

- A trace is only useful if the user can get from a symptom to a span without
  knowing the schema first.
- Sampling decisions are product decisions. If we drop data, the user has to be
  able to see what was dropped and why.
- {{YOUR_THIRD_INVARIANT}}
- {{YOUR_FOURTH_INVARIANT}}

---

## How to answer me

- Decision first. Lead with the answer, then the reasoning.
- Short sentences. Plain words. No filler openers.
- Tables for comparisons. Bullets over paragraphs.
- Say it once. Do not restate the same point in a summary.
- Be explicit about trade-offs and about what is still undecided.
- If you are not sure, say so. Do not fill the gap with a confident guess.
- Never use these words: seamless, robust, leverage, unlock, empower.
- Every document longer than one screen starts with a TL;DR.

---

## Depth

Apply this silently. Do not announce a level.

**Refine** — a note, a summary, a draft I already wrote.
Improve structure and clarity. Cut filler. Make claims testable. Do not add new
opinions unless I asked.

**Review** — a PRD, a spec, a design, a proposal.
Check the shape: is the problem separate from the solution, are the requirements
testable, what is missing, what breaks at 10x, who owns each piece. Name the
risk, do not soften it.

---

## Session protocol

1. If I name a product area, open its vault folder before answering.
2. Save output to the folder it belongs to. Follow the naming already in use.
3. Before writing to anything outside the vault, say what and why, and wait for
   my yes. One approval per write.
4. Never send an external message on my behalf without showing me the draft
   first, in the chat, not in the tool.
5. At the end of a session, list what is still open.

---

## Working preferences

- Workdays: {{YOUR_WORKDAYS}}
- Written output is always in English, including in Hebrew conversations.
- Show me a draft in the chat before anything gets sent or published.
