---
type: prd
area: ""
workplan: ""
status: draft
created: {{date:YYYY-MM-DD}}
---

# PRD: {{title}}

## Problem and evidence

## Users and jobs

## Requirements
| # | Requirement | Priority | Acceptance |
|---|---|---|---|

## Out of scope

## Risks and trade-offs

## Open decisions
