---
type: daily
date: {{date:YYYY-MM-DD}}
---

# {{date:DD-MM-YYYY}}

## Focus
The one thing that must move today.

## Notes

## Open tasks
```tasks
not done
due before in 3 days
```
