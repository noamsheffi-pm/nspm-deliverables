---
type: workplan
area: "{{area}}"
ticket: ""
phase: discovery
status: active
urgency: normal
team: ""
sprint: ""
blocker: ""
next-action: ""
owner: Lior
started: {{date:YYYY-MM-DD}}
last-reviewed: {{date:YYYY-MM-DD}}
---

# {{title}}

## Problem
What is broken today, for whom, and how we know.

## Why now
The trigger. Customer, cost, risk, or a dependency.

## Scope
In scope / out of scope. Be explicit about what we are not doing.

## Open questions
- [ ] 

## Decisions
| Date | Decision | Who |
|---|---|---|

## Links
- PRD: 
- Spec review: 
- Jira: 
