---
type: meeting
with: ""
area: ""
date: {{date:YYYY-MM-DD}}
---

# {{title}}

## Context
Why we met, one line.

## Notes

## Decisions
- 

## Actions
- [ ]  #Task
- [ ]  #follow-up
